package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import implementations.Cat;
import implementations.Dog;
import implementations.Elephant;
import implementations.Hippo;
import implementations.Lion;
import implementations.Rhino;
import implementations.Tiger;
import implementations.Wolf;
import levelone.Animal;

public class Zookeeper {

   private static List<Animal> animals = new ArrayList<>();

   public static void main(String[] args) throws FileNotFoundException {

      Zookeeper zookeeper = new Zookeeper();

      PrintStream o = new PrintStream(new File("dayatthezoo.out"));
      System.setOut(o);

      System.out.println("----- Day At the Zoo: Output -----"); //Expected output
      System.out.println("Zoo Opened.");
      System.out.println("");
      if(animals == null || animals.size() == 0) { //for unit testing
         animals = zookeeper.createZooAnimals();
      }
      zookeeper.performTasksSequentially();
      System.out.println("");
      System.out.println("Zoo Closed.");
   }

   public List<Animal> createZooAnimals() {
      List<Animal> allAnimals = new ArrayList<>();
      allAnimals.add(new Cat("Cheshire"));
      allAnimals.add(new Cat("Cuddles"));
      allAnimals.add(new Lion("Leo"));
      allAnimals.add(new Lion("Lewis"));
      allAnimals.add(new Tiger("Tigran"));
      allAnimals.add(new Tiger("Tigru"));
      allAnimals.add(new Elephant("Ellen"));
      allAnimals.add(new Elephant("Elson"));
      allAnimals.add(new Dog("Deo"));
      allAnimals.add(new Dog("Dawn"));
      allAnimals.add(new Hippo("Hank"));
      allAnimals.add(new Hippo("Hustler"));
      allAnimals.add(new Rhino("Rincon"));
      allAnimals.add(new Rhino("Ruben"));
      allAnimals.add(new Tiger("Ruben"));
      allAnimals.add(new Wolf("Will"));
      allAnimals.add(new Wolf("Wiz"));
      return allAnimals;
   }

   public void performTasksSequentially() {

      System.out.println("----------- wakeUpAnimals --------------");
      performFunction("wakeUpAnimals");
      System.out.println("----------- rollCallAnimals --------------");
      performFunction("rollCallAnimals");
      System.out.println("----------- feedAnimals --------------");
      performFunction("feedAnimals");
      System.out.println("------------ exerciseAnimals -------------");
      performFunction("exerciseAnimals");
      System.out.println("------------ shutDownZoo -------------");
      performFunction("shutDownZoo");

   }

   public void performFunction(String task) {
      for (Animal a : animals) {
         switch (task) {
         case "wakeUpAnimals":
            System.out.println(a.wakeUp());
            break;
         case "rollCallAnimals":
            System.out.println(a.makeNoise());
            break;
         case "feedAnimals":
            System.out.println(a.eat());
            break;
         case "exerciseAnimals":
            System.out.println(a.roam());
            break;
         case "shutDownZoo":
            System.out.println(a.sleep());
            break;
         default:
            System.out.println("Invalid task assigned to the zookeeper.");
         }
      }
   }

}
