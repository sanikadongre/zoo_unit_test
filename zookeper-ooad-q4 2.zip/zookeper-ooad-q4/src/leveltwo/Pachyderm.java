package leveltwo;

import levelone.Animal;

/*
   Level two of inheritance:
   Pachyderm overrides eat() and sleep() methods inherited from class Animal
   Demonstrates polymorphism since these specific methods can be invoked if wanted (instanceOf)
 */
public abstract class Pachyderm extends Animal {

   @Override
   public String eat() {
      return this.name + " The Pachyderm animal eats grass and/or some meat.";
   }

   @Override
   public String roam() {
      return this.name + " The Pachyderm animal roams in herds or by itself.";
   }
}
