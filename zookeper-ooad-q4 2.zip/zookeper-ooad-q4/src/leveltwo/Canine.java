package leveltwo;

import levelone.Animal;
/*
   Level two of inheritance:
   Canine overrides eat() and sleep() methods inherited from class Animal
   Demonstrates polymorphism since these specific methods can be invoked if wanted (instanceOf)
 */
public abstract class Canine extends Animal {

   @Override
   public String eat() {
      return this.name + " The Canine animal eats meat.";
   }

   @Override
   public String roam() {
      return this.name + " The Canine animal roams in pack.";
   }
}
