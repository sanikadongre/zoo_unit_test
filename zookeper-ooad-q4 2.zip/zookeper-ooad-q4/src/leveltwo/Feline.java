package leveltwo;

import levelone.Animal;

/*
   Level two of inheritance:
   Feline overrides eat() and sleep() methods inherited from class Animal
   Demonstrates polymorphism since these specific methods can be invoked if wanted (instanceOf)
 */
public abstract class Feline extends Animal {

   @Override
   public String eat() {
      return this.name + " The Feline animal eats raw meat.";
   }

   @Override
   public String roam() {
      return this.name + " The Feline animal roams individually/alone.";
   }
}
