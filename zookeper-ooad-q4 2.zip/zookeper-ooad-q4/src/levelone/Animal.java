package levelone;

/*
   Animal class is the topmost level (base class) abstract class that will be inherited in child classes
   All the property(ies) and methods inherited accross all child classes.
 */

public abstract class Animal {

   public String name; //Declaring name field in Animal since it's common to all "types" of animals.

   /*
      Wake and sleep functions can be generic hence no need to override.
      This will also demonstrate calling a base class method from the inheriting class instance.
    */
   public String wakeUp() {
      return this.name + " The animal wakes up.";
   }

   public String sleep() {
      return this.name + " The animal sleeps.";
   }

   /*
      Following methods will be overridden
      Some overridden in second level of inheritance/ others in third level of specific animal type classes
    */
   public String eat() {
      return this.name + " The animal eats.";
   }

   public abstract String makeNoise(); //demonstrates the use of the abstract method, without any body.

   public abstract String roam(); //demonstrates the use of the abstract method, without any body.

}
