package implementations;

import leveltwo.Feline;

public class Lion extends Feline {

   public Lion(String name) {
      this.name = name;
   }

   @Override
   public String makeNoise(){
      return this.name + " Lion makes noise LionGrrr.";
   }

   @Override
   public String roam(){
      return this.name + " Lion exercises by running quick and putting claws in trees.";
   }
}