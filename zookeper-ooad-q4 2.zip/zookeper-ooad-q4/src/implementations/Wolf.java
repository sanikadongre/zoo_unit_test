package implementations;

import leveltwo.Canine;

public class Wolf extends Canine {

   public Wolf(String name) {
      this.name = name;
   }

   @Override
   public String makeNoise(){
      return this.name + " Wolf makes noise Grrrrr.";
   }

   @Override
   public String roam(){
      return this.name + " Wolf exercises by stretching and licking itself.";
   }
}
