package implementations;

import leveltwo.Canine;

public class Dog extends Canine {

   public Dog(String name) {
      this.name = name;
   }

   @Override
   public String makeNoise(){
      return this.name + " Dog makes noise Woof.";
   }

   @Override
   public String roam(){
      return this.name + " Dog exercises by stretching and sprinting.";
   }

}
