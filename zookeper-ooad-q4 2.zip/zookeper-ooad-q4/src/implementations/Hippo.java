package implementations;

import leveltwo.Pachyderm;

public class Hippo extends Pachyderm {

   public Hippo(String name) {
      this.name = name;
   }

   @Override
   public String makeNoise(){
      return this.name + " Hippo makes noise Hipooo.";
   }

   @Override
   public String roam(){
      return this.name + " Hippo exercises by jumping up and down in the water.";
   }
}
