package implementations;

import leveltwo.Feline;

public class Tiger extends Feline {

   public Tiger(String name) {
      this.name = name;
   }

   @Override
   public String makeNoise(){
      return this.name + " Tiger makes noise Tigrrrrr.";
   }

   @Override
   public String roam(){
      return this.name + " Tiger exercises by running quick and putting claws in trees.";
   }
}
