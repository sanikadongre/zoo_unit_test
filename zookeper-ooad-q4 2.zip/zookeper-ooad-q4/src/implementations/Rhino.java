package implementations;

import leveltwo.Pachyderm;

public class Rhino extends Pachyderm {

   public Rhino(String name) {
      this.name = name;
   }

   @Override
   public String makeNoise(){
      return this.name + " Rhino makes noise Rhinooo.";
   }

   @Override
   public String roam(){
      return this.name + " Rhino exercises by jumping up and down in the grass.";
   }
}
