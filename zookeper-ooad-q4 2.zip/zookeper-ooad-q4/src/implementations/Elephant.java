package implementations;

import leveltwo.Pachyderm;

public class Elephant extends Pachyderm {

   public Elephant(String name) {
      this.name = name;
   }

   @Override
   public String makeNoise(){
      return this.name + " Elephant makes noise Mooooo.";
   }

   @Override
   public String roam(){
      return this.name + " Elephant exercises by moving and bathing in the muddy water.";
   }
}
