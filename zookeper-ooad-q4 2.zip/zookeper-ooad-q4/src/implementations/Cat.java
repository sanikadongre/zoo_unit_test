package implementations;

import leveltwo.Feline;

/*
   As asked part of the assignment:
   Cat is the only class that used Math.random to select between multiple responses to zookeeper tasks.
 */
public class Cat extends Feline {

   public Cat(String name) {
      this.name = name;
   }

   @Override
   public String makeNoise(){
      //use random number generation to select from alternative responses to animal actions
      if(Math.random() < .5){  //Math.random() generates number between 0 & 1
         return this.name + " Cat makes noise Meow.";
      } else {
         return this.name + " Cat makes noise Meowwww and Meowwww.";
      }
   }

   @Override
   public String roam(){
        //use random number generation to select from alternative responses to animal actions
      if(Math.random() < .5){ //Math.random() generates number between 0 & 1
         return this.name + " Cat exercises by stretching and licking itself.";
      } else {
         return this.name + " Cat exercises by playing with itself and purring.";
      }
   }
}
