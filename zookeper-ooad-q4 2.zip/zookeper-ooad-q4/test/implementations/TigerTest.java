package implementations;

import static org.junit.Assert.*;

import org.junit.Test;

public class TigerTest {

   private Tiger tiger = new Tiger("Teo");

   @Test
   public void makeNoise() {
      String ret = tiger.makeNoise();
      assertTrue(ret.equals("Teo Tiger makes noise Tigrrrrr."));
   }

   @Test
   public void roam() {
      String ret = tiger.roam();
      assertTrue(ret.equals("Teo Tiger exercises by running quick and putting claws in trees."));
   }
}