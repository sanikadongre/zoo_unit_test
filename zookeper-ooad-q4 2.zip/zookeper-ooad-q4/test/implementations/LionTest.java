package implementations;

import static org.junit.Assert.*;

import org.junit.Test;

public class LionTest {

   private Lion lion = new Lion("Leo");

   @Test
   public void makeNoise() {
      String ret = lion.makeNoise();
      assertTrue(ret.equals("Leo Lion makes noise LionGrrr."));
   }

   @Test
   public void  roam() {
      String ret = lion.roam();
      assertTrue(ret.equals("Leo Lion exercises by running quick and putting claws in trees."));
   }
}