package implementations;

import static org.junit.Assert.*;

import org.junit.Test;

public class ElephantTest {

   private Elephant elephant = new Elephant("Elle");

   @Test
   public void makeNoise() {
      String ret = elephant.makeNoise();
      assertTrue(ret.equals("Elle Elephant makes noise Mooooo."));
   }

   @Test
   public void roam() {
      String ret = elephant.roam();
      assertTrue(ret.equals("Elle Elephant exercises by moving and bathing in the muddy water."));
   }
}