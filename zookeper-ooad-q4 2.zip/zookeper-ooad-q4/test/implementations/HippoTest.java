package implementations;

import static org.junit.Assert.*;

import org.junit.Test;

public class HippoTest {

   private Hippo hippo = new Hippo("Hippie");

   @Test
   public void makeNoise() {
      String ret = hippo.makeNoise();
      assertTrue(ret.equals("Hippie Hippo makes noise Hipooo."));
   }

   @Test
   public void roam() {
      String ret = hippo.roam();
      assertTrue(ret.equals("Hippie Hippo exercises by jumping up and down in the water."));
   }
}