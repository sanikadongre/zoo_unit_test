package implementations;

import static org.junit.Assert.*;

import org.junit.Test;

public class WolfTest {

   private Wolf wolf = new Wolf("Wolverine");

   @Test
   public void makeNoise() {
      String ret = wolf.makeNoise();
      assertTrue(ret.equals("Wolverine Wolf makes noise Grrrrr."));
   }

   @Test
   public void roam() {
      String ret = wolf.roam();
      assertTrue(ret.equals("Wolverine Wolf exercises by stretching and licking itself."));
   }
}