package implementations;

import static org.junit.Assert.*;

import org.junit.Test;

public class CatTest{

   private Cat testcat = new Cat("Cheshire");

   @Test
   public void testMakeNoise() {
       String ret = testcat.makeNoise();
      assertTrue(ret.equals("Cheshire Cat makes noise Meow.") || ret.equals("Cheshire Cat makes noise Meowwww and Meowwww."));
   }

   @Test
   public void testRoam() {
      String ret = testcat.roam();
      assertTrue(ret.equals("Cheshire Cat exercises by stretching and licking itself.") || ret
            .equals("Cheshire Cat exercises by playing with itself and purring."));
   }
}