package implementations;

import static org.junit.Assert.*;

import org.junit.Test;

public class RhinoTest {

   private Rhino rhino = new Rhino("Ringo");

   @Test
   public void makeNoise() {
      String ret = rhino.makeNoise();
      assertTrue(ret.equals("Ringo Rhino makes noise Rhinooo."));
   }

   @Test
   public void roam() {
      String ret = rhino.roam();
      assertTrue(ret.equals("Ringo Rhino exercises by jumping up and down in the grass."));
   }
}