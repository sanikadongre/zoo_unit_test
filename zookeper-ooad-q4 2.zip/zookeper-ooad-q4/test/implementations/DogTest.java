package implementations;

import static org.junit.Assert.*;

import org.junit.Test;

public class DogTest {

   private Dog dog = new Dog("Darren");

   @Test
   public void makeNoise() {
      String ret = dog.makeNoise();
      assertTrue(ret.equals("Darren Dog makes noise Woof."));
   }

   @Test
   public void roam() {
      String ret = dog.roam();
      assertTrue(ret.equals("Darren Dog exercises by stretching and sprinting."));
   }
}