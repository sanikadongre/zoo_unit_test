package main;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

import org.junit.Test;

import levelone.Animal;

public class ZookeeperTest {

   Zookeeper zookeeperTest = new Zookeeper();

   @Test
   public void createZooAnimals() {
      List<Animal> animals = zookeeperTest.createZooAnimals();
      assertEquals(animals.size(), 17);
      assertEquals(animals.get(0).name, "Cheshire");
   }

   @Test
   public void performFunction() throws FileNotFoundException {
      zookeeperTest.performFunction("wakeUpAnimals");
      File file = new File("dayatthezoo.out");
      assertTrue(file.exists());
      assertTrue(file.canWrite() && file.canRead());
      file.toString();

      Scanner scanner = new Scanner(new File("dayatthezoo.out"));
      int count = 1;
      while (scanner.hasNextLine()) {
         String line = scanner.nextLine();
         // process the line
         if (count == 1) {
            assertTrue(line.contains("----- Day At the Zoo: Output -----"));
         } else {
            if (count == 2) {
               assertTrue(line.contains("Zoo Opened."));
            } else {
               if (count == 4) {
                  assertTrue(line.contains("----------- wakeUpAnimals --------------"));
               } else {
                  if (count == 5) {
                     assertTrue(line.contains("Cheshire The animal wakes up."));
                  }
               }
            }
         }
         count++;
      }

   }
}