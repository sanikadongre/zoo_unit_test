package leveltwo;

import static org.junit.Assert.*;

import org.junit.Test;

public class FelineTest {
   //This is an Abstract class.
   //The methods will be tested in the impolementation classes and the Zookeeper class with main() method.
   @Test
   public void eat() {
       //NONE
      //Will be tested in tests for Zookeeper
   }

   @Test
   public void roam() {
       //NONE
      //Will be tested in tests for Zookeeper
   }
}